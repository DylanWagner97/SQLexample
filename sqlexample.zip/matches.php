<!--
  Dylan Wagner
  Nerdluv for lab 8
-->

<?php include("top.html") ?>
		<!-- include top-->
	<form action="matches-submit.php" method="GET">
		<fieldset>
			<legend>Returning User:</legend>
			<ul>
				<li>
					<strong>Name:</strong>
					<input type="text" size="16" name="name"/>
				</li>
			</ul>
			<input type ="submit" value="View My Matches">
		</fieldset>
	</form>
		<!--end of html with bottom include-->
<?php include("bottom.html") ?>