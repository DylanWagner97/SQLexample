<?php
#Dylan Wagner lab8 nerd luv
header("Content-type: application/json");

/* This web service should handle two types of requests:
	1) a GET request with a name parameter 
	2) a POST request with the following parameters:
		- name
		- gender
		- age
		- ptype
		- os
		- minAge
		- maxAge
	You do not need to do validation checking on the values of the parameters.
	For this lab, we'll assume the values are all valid (no weird OS spellings, etc.)
	
	There are no results from the POST request. However, if a failure occurs, your
	page should return an HTTP error code of 400.
	
	The results of the GET request should be a json object named data with the set
	of matches as an array. For example:
	{"data":[{"name":"Dana Scully",
			  "gender":"F",
			  "age":"41",
			  "ptype":"ISTJ",
			  "os":"Mac OS X",
			  "minAge":"36",
			  "maxAge":"54"},
	         {"name":"Jadzia Dax",
			  "gender":"F",
			  "age":"46",
			  "ptype":"ENFJ",
			  "os":"Mac OS X",
			  "minAge":"18",
			  "maxAge":"32"}
			 ]
	}
	
	If no matches are found, return an empty data array (as follows):
	{"data":[]
	}
	If a failure occurs, your page should return an HTTP error code of 400.


/* Your db.txt file should contain two variable initializations:
	$username (probably "admin", your db username)
	$login (the password for your db login) */
include("/var/db.php");

/* You should put logic here to handle the POST request to add a new 
user and the GET request to get matches for a user */

$connection = getConnection($username, $login);

if ($_SERVER["REQUEST_METHOD"] == "GET") 
{
	# GET request for which method to execute
	$name = $_GET["name"];
	$user = getUser($connection, $name);
	$matches = getBasicMatches($connection, $user);
	$data = getMatches($user[3], $matches);
	$dataArray = array("data" => $data);
	print(json_encode($dataArray));
	if (!isset($_GET["name"])) 
	{
		#if name is not set return error 
		header("HTTP/1.1 400 Invalid Request");
		die("An HTTP error 400 (invalid request) occurred.");
	}
	
}
elseif ($_SERVER["REQUEST_METHOD"] == "POST") 
{
	# process a POST request
	$name = $_POST["name"];
	$gender = $_POST["gender"];
	$age = $_POST["age"];
	$ptype = $_POST["ptype"];
	$os = $_POST["os"];
	$minage = $_POST["minAge"];
	$maxage = $_POST["maxAge"];
	$added = addUser($connection, $name, $gender, $age, $ptype, $os, $minage, $maxage);
	if (!$added) 
	{
		# if user was not succesfully added return error code
		header("HTTP/1.1 400 Invalid Request");
		die("An HTTP error 400 (invalid request) occurred.");
	}
}

/* This function should take in the $username and $login that were initialized
	in the db.txt file and it should use PDO to connect to the database.
	The database connection should be returned. */
function getConnection($username, $login) 
{
	$db = new PDO("mysql:dbname=nerdluv", $username, $login);
	return $db;
}

/* This function takes in a PDO object that should already be connected to 
	the database and a variable $name that contains the user name. $name is the
	user for whom we want to find matches. This function should do a query (using 
	a prepared statement) and get the row that matches the $name as a *numerically
	indexed* array. This array should be returned. */
function getUser($dbconn, $name) 
{
	$statement = $dbconn->prepare("SELECT DISTINCT * FROM users WHERE name = :name");
	$statement->execute(array(':name' => $name));
	$rowNum = $statement->fetch();
	return $rowNum;
}

/* Given a PDO object (already connected to DB) and a numerically indexed array of data
	representing the row in the db for a user, return a result set of data that has
	1) the opposite gender from $user, 2) matching os, 3) an age between the minage of $user
	and maxage of $user and where the age of $user is between the minage and maxage of the
    record. (Ignore the personality type for now). Getting these results should be
	done by a prepared statement with parameters. Return the rows in a multi-dimensional 
	*associative* array (unless there are no results) */
function getBasicMatches($dbconn, $user) 
{
	$statement = $dbconn->prepare("SELECT * FROM users WHERE gender != :gender AND os = :os AND age >= :minAge AND age <= :maxAge AND minAge <= :age AND maxAge >= :age");
	$statement->execute(array(':gender' => $user[1], ':age' => $user[2], ':os' => $user[4], ':minAge' => $user[5], ':maxAge' => $user[6]));
	$rowNum = $statement->fetchAll();
	return $rowNum;
}

/* Given the string representing the user's personality type and the result set from
	getting the user's basic matches (getBasicMatches), return an array containing only those
	matches that have at least one personality type letter in common with $usertype The $matches
	should be multi-dimensional associative array when passed in, and the return value should
	also be a multi-dimensional associative array (unless there are no results) */
function getMatches($usertype, $matches) 
{
	$mArray = array();
	foreach($matches as $match)
	{
		$ptype = $match[3];
		$added = false;
		for($i = 0; $i < 4;$i++)
		{
			if($ptype[$i] == $usertype[$i]){
				$added = true;
			break;
			}
		}
		if($added)
		{
			array_push($mArray, $match);
		}
	}
	return $mArray;
}

/* Given a PDO object (already connected to DB) and all of the information necessary for
	a new user, this function should add the new user to the database. Return value should be
	true or false */
function addUser($dbconn, $name, $gender, $age, $ptype, $os, $minage, $maxage) 
{
	$statement = $dbconn->prepare("INSERT INTO users VALUES (:name, :gender, :age, :type, :os, :minAge, :maxAge)");
	$addedUser =  $statement->execute(array(':name' => $name, ':gender' => $gender, ':age' => $age, ':type' => $ptype, ':os' => $os, ':minAge' => $minage, ':maxAge' => $maxage));
	return $addedUser;
}





?>
