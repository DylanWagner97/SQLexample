<!--
Dylan Wagner
NerdLuv for lab 8
-->

<?php 
  include("top.html");
?>
<!-- Start of PHP content-->
<?php
  #call web service host 
  $userName = $_GET["name"];
  $Var = http_build_query($_GET);
  $url = "http://".$_SERVER['HTTP_HOST']."/Lab8/nerdluv.php?$Var";
  $file = file_get_contents($url);
  $web_array = json_decode($file, TRUE);
?>
<h1>Matches for <?=$userName?></h1>
<?php
#for loop to display all matches
for ($i = 0; $i < count($web_array["data"]); $i++) {
?>

<div class="match">
  <p>
    <img src="http://drwagner.millersville.edu/Lab8/images/user.jpg" alt="user icon" /> <?=  $web_array["data"][$i]["name"]  ?>
  </p>
  <ul>
      <li><strong>gender:</strong> <?=  $web_array["data"][$i]["gender"]  ?></li>
      <li><strong>age:</strong> <?=  $web_array["data"][$i]["age"]  ?></li>
      <li><strong>type:</strong> <?=  $web_array["data"][$i]["ptype"]  ?></li>
      <li><strong>OS:</strong> <?=  $web_array["data"][$i]["os"]  ?></li>                        
    </ul>
</div>

<?php
  }
?>

<!-- end html, much shorter file using web -->
<?php include("bottom.html") ?>