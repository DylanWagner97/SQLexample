<!--
  Dylan Wagner
  NerdLuv modified for lab 8
-->

<?php include("top.html");
#include top
	$post_data = http_build_query($_POST);
	$url = "http://".$_SERVER['HTTP_HOST']."/Lab8/nerdluv.php";
	$opts = array('http' =>
		array(
		'method' => 'POST',
		'header' => 'Content-Type: application/x-www-form-urlencoded',
		'content' => $post_data
		)
	);
	$context = stream_context_create($opts);
	file_get_contents($url,false,$context);
?>

<div>
	<h1>Thank you!</h1>
	<p>
		Welcome to NerdLuv, <?= $_POST["name"] ?>!<br /> <br />
		Now <a href="matches.php">log in to see your matches!</a>
	</p>
</div>	
<!--include bottom -->
<?php include("bottom.html") ?>